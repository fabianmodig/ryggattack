// Real image smoke; no mock HTTP/socket endpoints. ENGINE=podman locally, docker in CI.
import assert from 'node:assert/strict';
import {execFile,spawn} from 'node:child_process';
import {promisify} from 'node:util';
import fs from 'node:fs';
import crypto from 'node:crypto';
import net from 'node:net';
import {smokeNetworkArgs,smokeHttpUrl} from './container-smoke-network.mjs';
const networkContainer=process.env.CONTAINER_SMOKE_NETWORK_CONTAINER;
const exec=promisify(execFile),engine=process.env.ENGINE??'docker';
const [web,server]=process.argv.slice(2);assert(web&&server,'web and backend image required');
const names={web:`ryggattack-web-${process.pid}`,server:`ryggattack-server-${process.pid}`};
const cli=async(...args)=>(await exec(engine,args,{maxBuffer:1024*1024})).stdout.trim();
const sleep=ms=>new Promise(r=>setTimeout(r,ms));
const until=async(p,label)=>{let lastError;for(let i=0;i<100;i++){try{if(await p())return;}catch(error){lastError=error;}await sleep(100);}throw Error(label+(lastError?`: ${lastError.cause?.code??lastError.message}`:''));};
const sha=b=>crypto.createHash('sha256').update(b).digest('hex');
const startBackend=async()=>await cli('run','-d','--name',names.server,'--read-only','--cap-drop=ALL','--security-opt=no-new-privileges','-e','RYGGATTACK_MODE=production','-e','RYGGATTACK_ALLOWED_ORIGINS=https://ryggattack.modig.online','-e','RYGGATTACK_MANAGEMENT_BIND=0.0.0.0:8788',...smokeNetworkArgs([8787,8788],networkContainer),server);
try {
 await cli('run','-d','--name',names.web,'--read-only','--cap-drop=ALL','--security-opt=no-new-privileges','--tmpfs','/tmp:rw,noexec,nosuid,size=16m',...smokeNetworkArgs([8080],networkContainer),web);
 await startBackend();
 const url=async(name,port)=>smokeHttpUrl(port,networkContainer===undefined?(await cli('port',name,`${port}/tcp`)).split('\n')[0]:undefined,networkContainer);
 const webURL=await url(names.web,8080),wsURL=(await url(names.server,8787)).replace('http:','ws:')+'/ws',management=await url(names.server,8788);
 await until(async()=> (await fetch(webURL)).status===200,'web readiness');
 await until(async()=> (await fetch(management+'/readyz')).status===200,'backend readiness');
 assert((await (await fetch(webURL)).text()).includes('ryggattack-canvas'));
 for(const file of ['index.html','rooms.mjs','ryggattack.js','ryggattack_bg.wasm']){
  const r=await fetch(webURL+'/'+file);assert.equal(r.status,200);
  const type=r.headers.get('content-type');if(file.endsWith('.wasm'))assert.match(type,/application\/wasm/);if(file.endsWith('.mjs'))assert.match(type,/javascript/);
  assert.equal(sha(Buffer.from(await r.arrayBuffer())),sha(fs.readFileSync('dist/web/'+file)),`${file} exact image artifact`);
 }
 // Capture BOTH streams: Docker emits container stderr on CLI stderr.
 const logs=async()=>{const r=await exec(engine,['logs',names.web],{maxBuffer:1024*1024});return r.stdout+r.stderr;};
 const marker=crypto.randomUUID(),privateQuery=`phase5-query-${marker}`,privateReferer=`phase5-referer-${marker}`;
 const headers={Referer:`https://private.invalid/?room=${privateReferer}&name=${privateReferer}`};
 for(const [route,status] of [['/',200],['/missing-private.mjs',404],['/missing-private.wasm',404],['/missing-private.js',404],['/missing-private',404],['/%00.mjs',400],['/%ZZ.wasm',400]]){
  assert.equal((await fetch(webURL+route+'?name='+privateQuery+'&room='+privateQuery,{headers})).status,status,route);
 }
 // Raw request avoids URL normalization and exercises the early parser path.
 const malformed=await new Promise((resolve,reject)=>{
  const u=new URL(webURL),socket=net.connect(Number(u.port),u.hostname);let response='';
  socket.setTimeout(3000,()=>socket.destroy(Error('malformed HTTP response timed out')));
  socket.once('connect',()=>socket.write(`GE(T /missing-private.mjs?name=${privateQuery} HTTP/1.1\r\nHost: localhost\r\nReferer: ${headers.Referer}\r\nConnection: close\r\n\r\n`));
  socket.on('data',chunk=>response+=chunk);socket.once('error',reject);socket.once('end',()=>resolve(response));
 });
 assert.match(malformed,/^HTTP\/1\.1 400 /);
 await sleep(100);
 const webLogs=await logs();
 assert(!webLogs.includes(privateQuery)&&!webLogs.includes(privateReferer),`web logs must not disclose query or Referer on successful, missing-asset or malformed requests:\n${webLogs}`);
 assert(webLogs.includes('"event":"http_request"'),'sanitized access diagnostics remain enabled');
 // Request-log suppression must not discard global startup diagnostics.
 let startupFailure;
 try{await exec(engine,['run','--rm','--read-only','--cap-drop=ALL','--security-opt=no-new-privileges','--tmpfs','/tmp:rw,noexec,nosuid,size=16m',web,'-c','/missing-phase5-nginx.conf','-t']);}catch(error){startupFailure=error;}
 assert(startupFailure,'invalid nginx startup configuration must fail');
 assert.match(startupFailure.stderr,/\[emerg\].*missing-phase5-nginx\.conf/,'global infrastructure errors remain on stderr');
 for(const route of ['/metrics','/healthz','/readyz','/ws'])assert.equal((await fetch(webURL+route)).status,404,'web must not expose backend/management');
 const result=await new Promise(r=>{const c=spawn(process.execPath,['scripts/production-smoke.mjs'],{env:{...process.env,PRODUCTION_WS:wsURL,PRODUCTION_MANAGEMENT:management},stdio:'inherit'});c.once('exit',r);});assert.equal(result,0);
 // Exercise the chart's actual Recreate contract. A fresh network namespace
 // avoids Podman/pasta's rapid same-port restart race without hiding app errors.
 await cli('stop','--time','10',names.server);await cli('rm',names.server);
 names.server=`ryggattack-server-recreated-${process.pid}`;await startBackend();
 const resetManagement=await url(names.server,8788),resetWS=(await url(names.server,8787)).replace('http:','ws:')+'/ws';
 await until(async()=> (await fetch(resetManagement+'/readyz')).status===200,'recreated backend ready');
 assert.match(await (await fetch(resetManagement+'/metrics')).text(),/ryggattack_rooms 0\n/);
 const ws=new WebSocket(resetWS),messages=[];let closed=false;
 ws.addEventListener('message',e=>messages.push(JSON.parse(e.data)));ws.addEventListener('close',()=>closed=true);
 await new Promise((r,j)=>{ws.addEventListener('open',r);ws.addEventListener('error',j);});ws.send(JSON.stringify({Hello:{version:4,name:'Shutdown probe'}}));
 await until(()=>messages.some(m=>m.Welcome),'shutdown client admitted');
 ws.send(JSON.stringify({Ready:true}));await until(()=>messages.some(m=>m.State),'shutdown client receives actual running simulation');
 const start=performance.now();await cli('stop','--time','10',names.server);assert(performance.now()-start<2000,'container bounded SIGTERM shutdown');
 await until(()=>closed,'shutdown closes client');assert(messages.some(m=>m.Error?.includes('backend restarting')));
 const inspect=JSON.parse(await cli('inspect',names.server))[0];assert.equal(inspect.State.ExitCode,0);
 const configs={};for(const [component,name] of Object.entries(names)){const i=JSON.parse(await cli('inspect',name))[0];assert(i.Config.User&&i.Config.User!=='0');assert(i.HostConfig.ReadonlyRootfs);configs[component]={image:i.Image,user:i.Config.User,readonly:i.HostConfig.ReadonlyRootfs,capDrop:i.HostConfig.CapDrop};}
 console.log(JSON.stringify({checks:['actual nonroot read-only cap-drop images','exact JS/WASM/HTML/module bytes and MIME','no public management routes','production socket/abuse contract','same-image Recreate resets all in-memory rooms','container SIGTERM notifies and closes real client with exit 0'],images:configs},null,2));
} catch(error) {
 // Preserve owned-container failure diagnostics before cleanup; never dump Env.
 for(const name of Object.values(names))try{
  const state=JSON.parse(await cli('inspect','--format','{{json .State}}',name));
  const logs=await exec(engine,['logs',name],{maxBuffer:1024*1024});
  console.error(JSON.stringify({container:name,state,logs:(logs.stdout+logs.stderr).slice(-8000)}));
 }catch{}
 throw error;
} finally {for(const name of Object.values(names))try{await cli('rm','-f',name);}catch{}}
