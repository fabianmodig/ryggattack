import json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2]
n=json.loads((ROOT/'verification/arena-presentation/checks-20261025T123854Z/result.json').read_text())
b=json.loads((ROOT/'verification/final-acceptance/build-20261025T124108Z/result.json').read_text())
assert n['status']=='passed'
assert all(b['sources'][p]==h for p,h in n['source_hashes'].items())
log=(ROOT/'verification/final-acceptance/build-20261025T124108Z/all-node-unit-gates.log').read_text()
print(json.dumps({'native_passed':n['native_passed'],'native_durations':[{k:s[k] for k in ['name','status','seconds']} for s in n['stages']],'source_equivalence_native_to_final_build':True,'all_node_tail':log[-1400:],'build_status':b['status']},indent=2))
