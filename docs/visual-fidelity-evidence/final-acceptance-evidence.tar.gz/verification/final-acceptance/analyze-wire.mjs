import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import {assertSharedExplosionEvidence} from '../../scripts/online-explosion-evidence.mjs';
const root=process.argv[2];const clients=JSON.parse(fs.readFileSync(path.join(root,'states.json')));
const results=[];
for(const match of [...new Set(clients[0].frames.map(x=>x.match??x.room))]){
 const frames=c=>c.frames.filter(x=>(x.match??x.room)===match).map(x=>x.frame);
 const proof=assertSharedExplosionEvidence(frames(clients[0]),frames(clients[1]));
 results.push({match_or_room:match,...proof});
}
const out=path.join(root,'../'+path.basename(root)+'-wire-analysis.json');
fs.writeFileSync(out,JSON.stringify({scope:'post-run public wire classifier only; does NOT change original failed status or prove rendered pixels',complete:results.some(r=>r.complete),matches:results},null,2)+'\n');
console.log(JSON.stringify({out,complete:results.some(r=>r.complete),matches:results.map(r=>({match:r.match_or_room,shared_frames:r.shared_frames,wall:r.wall,chain:r.chain}))}));
assert(results.some(r=>r.complete),'shared wall/prop-chain evidence incomplete');
