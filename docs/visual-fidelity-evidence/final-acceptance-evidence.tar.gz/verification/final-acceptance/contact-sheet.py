from pathlib import Path
import sys
from PIL import Image, ImageDraw
root=Path(sys.argv[1]);prefix=sys.argv[2];start=int(sys.argv[3]) if len(sys.argv)>3 else 0
files=sorted(root.glob(prefix+'*.jpg'))[start:start+12]
assert files
out=Image.new('RGB',(1600,984),(15,15,15));draw=ImageDraw.Draw(out)
for i,p in enumerate(files):
    img=Image.open(p).convert('RGB');img.thumbnail((400,300));x=(i%4)*400;y=(i//4)*328
    out.paste(img,(x,y));draw.text((x+3,y+301),p.name,fill='white')
target=root.parent/(root.name+'-'+prefix+str(start)+'-contact.jpg');out.save(target,quality=90)
print(str(target))
