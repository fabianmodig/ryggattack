from pathlib import Path
import hashlib,json,collections
ROOT=Path(__file__).resolve().parents[2]
def sha(p):
 with open(p,'rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
b=json.loads((ROOT/'verification/final-acceptance/build-20261025T124108Z/result.json').read_text())
assert all(sha(ROOT/p)==h for p,h in b['sources'].items())
assert all(sha(ROOT/p)==h for p,h in b['artifacts'].items())
assert all(sha(p)==h for p,h in b['native'].items())
print('Runtime/source/native/artifact freeze unchanged')
for p in sorted((ROOT/'verification/final-acceptance').glob('browser-*/results.json')):
 r=json.loads(p.read_text());checks=r.get('checks',[])
 print(json.dumps({'run':p.parent.name,'status':r['status'],'mode':r.get('mode'),'checks':checks,'images':len(r.get('images',[])),'sequence':dict(collections.Counter(x['file'].rsplit('-',1)[0] for x in r.get('sequence',[]))),'cleanup':r.get('cleanup'),'errors':r.get('errors'),'failure':r.get('failure'),'private_scan':r.get('private_material_negative_scan'),'leave_readbacks':sum('explicit Leave' in c['name'] for c in checks)},indent=2))
