// Local real-render lifecycle acceptance; no injected gameplay or protocol commands.
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import http from 'node:http';
import net from 'node:net';
import crypto from 'node:crypto';
import {spawn} from 'node:child_process';
import {createRequire} from 'node:module';
import {fileURLToPath} from 'node:url';
import {canonical,redact} from '../../scripts/live-deployment-helpers.mjs';
import {capturePrivateScreenshot,publishSoloEvidence} from '../../scripts/solo-bots-helpers.mjs';
import {watchOwnedProcess,stopOwnedProcess,stopOwnedBrowser} from '../../scripts/online-explosion-cleanup.mjs';
import {assertSharedExplosionEvidence} from '../../scripts/online-explosion-evidence.mjs';
const ROOT=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'../..');
const WEB=path.join(ROOT,'dist/web'), BIN=path.join(ROOT,'target/debug');
const OUT=path.join(ROOT,'verification/final-acceptance','browser-'+new Date().toISOString().replace(/[:.]/g,'-'));
fs.mkdirSync(OUT,{recursive:true});
const sha=b=>crypto.createHash('sha256').update(b).digest('hex');
const sleep=ms=>new Promise(r=>setTimeout(r,ms));
const start=performance.now(),now=()=>Math.round(performance.now()-start);
const report={status:'running',scope:'local two independently rendered WASM clients (fixed sparse presentation), then offline alone pinned quality=0',mode:process.argv.includes('--recovery-offline')?'recovery-offline-supplement':'full-lifecycle',checks:[],errors:[],images:[],cleanup:[],events:[]};
const secrets=new Set(),clients=[],browsers=[],pipes=new Set(),blocked=new Set();
let origin,address,backend,backendLife,front,privacyFailed=false,expectedOutage=false;
const {chromium}=createRequire('/home/hermes/.npm/_npx/e41f203b7505f1fb/node_modules/playwright/package.json')('playwright');
async function until(p,label,ms=90000,cleanup=false){const end=now()+ms;while(!p()){assert(now()<end,label);if(!cleanup)assert.equal(report.errors.length,0,'unexpected browser/protocol error');await sleep(25);}}
function check(name,data={}){report.checks.push({name,at_ms:now(),...data});console.log('CHECK '+name);}
async function expand(c,open=true){if(await c.page.locator('#online-entry').evaluate(e=>e.open)!==open)await c.page.locator('#online-entry summary').click();}
function observe(c,ws){
 assert.equal(ws.url(),address);c.socketClosed=false;
 ws.on('close',()=>c.socketClosed=true);
 ws.on('framereceived',({payload})=>{try{
  const m=JSON.parse(String(payload));redact(m,secrets);
  if(m.Welcome){const w=m.Welcome;c.identity={room:w.room,participant:w.participant,seat:w.seat};c.code=w.code;c.welcomes.push({at_ms:now(),...c.identity});}
  if(m.Lobby){c.lobby=m.Lobby;c.lobbies.push({at_ms:now(),room:m.Lobby.id,phase:m.Lobby.phase,settings:m.Lobby.settings,humans:m.Lobby.humans.map(h=>({id:h.id,seat:h.seat,name:h.name,connected:h.connected}))});}
  if(m.State){const f=m.State;assert.equal(new Set(f.bodies.map(b=>b.id)).size,f.bodies.length,'unique authoritative IDs');c.last=f;c.frames.push({at_ms:now(),room:c.identity.room,arena:c.lobby.settings.arena,frame:f});}
  if(m.Error)throw Error('server Error');
 }catch(e){report.errors.push({client:c.name,error:e.message});}});
 ws.on('framesent',({payload})=>{const m=JSON.parse(String(payload));redact(m,secrets);if(m.Input)c.inputs.push({at_ms:now(),...m.Input});if(m==='Leave')c.leaves++;});
}
async function local(){
 front=http.createServer((req,res)=>{
  let f;try{let p=decodeURIComponent(req.url.split('?')[0]);if(p.includes('\0'))throw Error();if(p.endsWith('/'))p+='index.html';f=path.resolve(WEB,'.'+p);}catch{res.writeHead(400).end();return;}
  if(!f.startsWith(WEB+path.sep)){res.writeHead(403).end();return;}
  fs.readFile(f,(e,b)=>{if(e){res.writeHead(404).end();return;}res.writeHead(200,{'content-type':({'.html':'text/html','.mjs':'text/javascript','.js':'text/javascript','.wasm':'application/wasm'})[path.extname(f)]??'application/octet-stream','content-security-policy':"connect-src 'self' ws://127.0.0.1:*; object-src 'none'"}).end(b);});
 });
 await new Promise(r=>front.listen(0,'127.0.0.1',r));origin=`http://127.0.0.1:${front.address().port}`;address=origin.replace('http:','ws:')+'/ws';
 backend=spawn(path.join(BIN,'ryggattack-server'),['127.0.0.1:0'],{env:{HOME:'/home/hermes',PATH:process.env.PATH,RYGGATTACK_ALLOWED_ORIGINS:origin},stdio:['ignore','pipe','pipe']});backendLife=watchOwnedProcess(backend);
 backend.stderr.on('data',b=>report.events.push({at_ms:now(),server:String(b).replace(/(?:https?|wss?):\/\/[^\s]+/g,'[local endpoint]')}));
 const port=await new Promise((r,j)=>{let text='';backend.once('error',j);backend.stdout.on('data',b=>{text+=b;const m=/ws:\/\/127\.0\.0\.1:(\d+)/.exec(text);if(m)r(+m[1]);});setTimeout(()=>j(Error('server startup')),10000).unref();});
 front.on('upgrade',(req,down,head)=>{
  const name=req.headers['user-agent'];if(req.url!='/ws'||blocked.has(name)){down.destroy();return;}
  const up=net.connect(port,'127.0.0.1'),p={name,up,down};pipes.add(p);
  for(const s of [up,down]){s.on('error',()=>{up.destroy();down.destroy();});s.on('close',()=>pipes.delete(p));}
  up.write(`${req.method} ${req.url} HTTP/${req.httpVersion}\r\n${Object.entries(req.headers).map(([k,v])=>`${k}: ${v}`).join('\r\n')}\r\n\r\n`);if(head.length)up.write(head);down.pipe(up);up.pipe(down);
 });
}
async function browser(name,offline=false){
 const c={name,frames:[],inputs:[],welcomes:[],lobbies:[],leaves:0};clients.push(c);
 const owned=await chromium.launchServer({host:'127.0.0.1',args:['--use-angle=swiftshader','--enable-unsafe-swiftshader','--ignore-gpu-blocklist','--disable-backgrounding-occluded-windows','--disable-renderer-backgrounding']});
 const entry={owned,lifecycle:watchOwnedProcess(owned.process()),client:c};browsers.push(entry);
 entry.browser=await chromium.connect(owned.wsEndpoint());c.entry=entry;
 const ctx=await entry.browser.newContext({viewport:{width:800,height:600},userAgent:name});
 await ctx.route('**/*',r=>new URL(r.request().url()).origin===origin||['blob:','data:'].includes(new URL(r.request().url()).protocol)?r.continue():r.abort());
 c.page=await ctx.newPage();c.page.setDefaultTimeout(60000);
 c.page.on('websocket',ws=>observe(c,ws));
 c.page.on('pageerror',e=>report.errors.push({client:name,error:e.message}));
 c.page.on('console',m=>{if(m.type()==='error'){if(expectedOutage&&m.text().includes('WebSocket'))report.events.push({expected:'socket outage error',at_ms:now()});else report.errors.push({client:name,error:m.text().replace(/(?:https?|wss?):\/\/[^\s]+/g,'[local endpoint]')});}});
 c.page.on('crash',()=>report.errors.push({client:name,error:'crashed'}));
 await c.page.goto(origin+'/?quality=0',{waitUntil:'domcontentloaded'});
 await c.page.waitForFunction(()=>!document.getElementById('status'),null,{timeout:120000});
 if(!offline)await admit(c);
 return c;
}
async function admit(c,code){
 await expand(c);await c.page.locator('#backend').fill(address);await c.page.locator('#player-name').fill(c.name);await c.page.locator('#room-code').fill(code??'');
 const n=c.welcomes.length;await c.page.locator(code?'#join-room':'#create-room').click();await until(()=>c.welcomes.length>n&&c.lobby,'actual UI admission',120000);
 await c.page.waitForFunction(()=>JSON.parse(globalThis.ryggattackRoom??'{}').lobby,null,{timeout:120000});
}
async function present(c){return c.page.evaluate(()=>{const h=JSON.parse(globalThis.ryggattackHud??'null'),r=JSON.parse(globalThis.ryggattackRoom??'null');return {seat:h?.seat,phase:h?.lobby?.phase,room:h?.lobby?.id,arena:r?.lobby?.settings?.arena,tick:h?.frame?.tick,menu:h?.menu,players:document.querySelectorAll('.oh-player').length,canvas:[...document.querySelectorAll('canvas')].map(e=>({w:e.width,h:e.height}))};});}
async function stream(c){
 if(c.cdp)return;
 c.cdp=await c.page.context().newCDPSession(c.page);c.streamFrames=0;c.sequenceCounts={};
 // Public DOM scan before any pixels. No storage, Welcome or credentials are displayed.
 await capturePrivateScreenshot(c.page,secrets,async()=>{});
 c.cdp.on('Page.screencastFrame',e=>{
  c.latestPixels={bytes:Buffer.from(e.data,'base64'),at_ms:now(),timestamp:e.metadata.timestamp};c.streamFrames++;
  c.cdp.send('Page.screencastFrameAck',{sessionId:e.sessionId}).catch(()=>{});
  if(c.label&&c.lobby?.phase==='Running'&&(c.sequenceCounts[c.label]??0)<48){
   const index=c.sequenceCounts[c.label]??0;c.sequenceCounts[c.label]=index+1;
   const file=`sequence-${c.name}-${c.label}-${String(index).padStart(3,'0')}.jpg`;fs.writeFileSync(path.join(OUT,file),c.latestPixels.bytes);
   (report.sequence??=[]).push({file,at_ms:now(),compositor_timestamp:e.metadata.timestamp,wire_tick:c.last?.tick,explosion_ids:c.last?.bodies.filter(b=>b.kind===4).map(b=>b.id),sha256:sha(c.latestPixels.bytes),caveat:'actual compositor frame, not exact wire-to-GPU synchronization'});
  }
 });
 await c.cdp.send('Page.startScreencast',{format:'jpeg',quality:90,maxWidth:800,maxHeight:600,everyNthFrame:1});
}
async function shot(c,label){
 const before={at_ms:now(),identity:c.identity??null,presentation:await present(c),wire_tick:c.last?.tick??null};
 const file=c.name+'-'+label+'.jpg';
 if(process.argv.includes('--direct')){
  if(!c.cdp)c.cdp=await c.page.context().newCDPSession(c.page);else await c.cdp.send('Page.stopScreencast').catch(()=>{});
  await capturePrivateScreenshot(c.page,secrets,async()=>{const image=await Promise.race([c.cdp.send('Page.captureScreenshot',{format:'jpeg',quality:90,fromSurface:true,captureBeyondViewport:false}),sleep(60000).then(()=>{throw Error('direct screenshot deadline');})]);fs.writeFileSync(path.join(OUT,file),Buffer.from(image.data,'base64'));});
  const bytes=fs.readFileSync(path.join(OUT,file));report.images.push({file,sha256:sha(bytes),before,after_ms:now(),capture:'direct CDP'});return bytes;
 }
 await stream(c);const count=c.streamFrames;
 try{await capturePrivateScreenshot(c.page,secrets,async()=>{await until(()=>c.streamFrames>count,'fresh compositor capture',60000);fs.writeFileSync(path.join(OUT,file),c.latestPixels.bytes);});}catch(e){if(e.name==='PrivacyViolation')privacyFailed=true;throw e;}
 const bytes=fs.readFileSync(path.join(OUT,file));report.images.push({file,sha256:sha(bytes),before,after_ms:now(),compositor_frame:c.latestPixels.timestamp,after_wire_tick:c.last?.tick??null});return bytes;
}
async function focus(c){await expand(c,false);await c.page.locator('canvas').focus();}
async function tap(c,key){await c.page.keyboard.down(key);await sleep(900);await c.page.keyboard.up(key);await sleep(900);}
async function config(c,arena,target=7){await expand(c);await c.page.locator('#arena-room').selectOption(arena);await c.page.locator('#target-room').selectOption(String(target));await c.page.locator('#bots-room').fill('0');await c.page.locator('#apply-room').click();await until(()=>c.lobby.settings.arena===arena&&c.lobby.settings.wins_target===target&&c.lobby.settings.bots===0,'settings reflected');}
async function ready(a,b){for(const c of [a,b]){await expand(c);await until(()=>c.lobby.phase==='Lobby','ready only from Lobby');await c.page.locator('#ready-room').click();}await until(()=>[a,b].every(c=>c.lobby.phase==='Running'&&c.last),'both Running');for(const c of [a,b]){await focus(c);await c.page.keyboard.down('Space');}await a.page.keyboard.down('a');}
function agreement(a,b,from,arena){
 const room=a.identity.room;const peer=new Map(b.frames.filter(x=>x.at_ms>=from&&x.room===room&&x.arena===arena).map(x=>[x.frame.tick,x.frame]));
 const common=a.frames.filter(x=>x.at_ms>=from&&x.room===room&&x.arena===arena&&peer.has(x.frame.tick));
 assert(common.length>=8,'at least eight common frames');for(const x of common)assert.deepEqual(canonical(x.frame),canonical(peer.get(x.frame.tick)));
 const first=common[0],last=common.at(-1);return {common_frames:common.length,first_tick:first.frame.tick,last_tick:last.frame.tick,observed_hz:(last.frame.tick-first.frame.tick)/((last.at_ms-first.at_ms)/1000)};
}
async function leave(c,peer){
 if(!c.identity||c.left)return;
 await c.page.keyboard.up('Space');await c.page.keyboard.up('a');await expand(c);const n=c.leaves;await c.page.locator('#leave-room').click();await until(()=>c.leaves>n,'Leave sent',15000,true);
 await c.page.waitForFunction(()=>{const r=JSON.parse(globalThis.ryggattackRoom??'{}'),h=JSON.parse(globalThis.ryggattackHud??'{}');return r.status?.includes('Left room')&&!r.lobby&&h.seat===null&&h.frame===null&&document.querySelectorAll('.oh-player').length===0;},null,{timeout:15000});
 await until(()=>c.socketClosed,'Leave socket close',15000,true);
 if(peer&&!peer.left){await until(()=>!peer.lobby.humans.some(h=>h.id===c.identity.participant),'peer roster removal',15000,true);}
 c.left=true;check(c.name+' explicit Leave + empty HUD + socket close + peer roster',{identity:c.identity});
}
async function close(c){
 if(c.closed)return;if(c.cdp)await c.cdp.send('Page.stopScreencast').catch(()=>{});if(!c.page.isClosed())await c.page.close();
 const r=await stopOwnedProcess(c.entry.lifecycle,async()=>{await c.entry.owned.close();await c.entry.browser.close();},{closeMs:60000});
 let gone=false;try{process.kill(c.entry.owned.process().pid,0);}catch(e){if(e.code==='ESRCH')gone=true;else throw e;}
 report.cleanup.push({name:c.name,browser:r,owned_process_absent:gone,graceful_exit:r.valid,caveat:'A requested teardown SIGKILL is retained, not relabeled a clean exit; unexpected exits still fail.'});
 assert(gone&&r.requested&&!r.unexpected&&r.exit,'owned browser termination readback');c.closed=true;
}
async function run(){
 const a=await browser('ArenaA');const b=await browser('ArenaB',true);await admit(b,a.code);
 assert.notEqual(a.entry.owned.process().pid,b.entry.owned.process().pid);assert.equal(a.identity.room,b.identity.room);assert.notEqual(a.identity.seat,b.identity.seat);
 check('two independent Chromium processes and distinct seats');
 if(process.argv.includes('--recovery-offline')||process.argv.includes('--reload-only')){
  await config(a,'Volcano',7);const from=now();await ready(a,b);for(const c of [a,b]){await stream(c);c.label='recovery-Volcano';}
  await until(()=>[a,b].every(c=>c.frames.filter(x=>x.at_ms>from).length>16),'supplement concurrent actual states');
  check('supplement two rendered clients common snapshots',agreement(a,b,from,'Volcano'));await shot(a,'pre-reload');await shot(b,'pre-leave');
  await leave(b,a);await close(b);const identity={...a.identity},count=a.welcomes.length;expectedOutage=true;
  await a.page.reload({waitUntil:'domcontentloaded'});await until(()=>a.welcomes.length>count,'reload saved seat',120000);assert.deepEqual(a.identity,identity);expectedOutage=false;
  await a.page.waitForFunction(()=>{const h=JSON.parse(globalThis.ryggattackHud??'{}');return h.lobby?.phase==='Running'&&h.frame?.tick>0;},null,{timeout:90000});await sleep(3000);
  await shot(a,'reload-volcano');check('actual reload restores same saved seat after second renderer exits');await leave(a);await close(a);
  if(!process.argv.includes('--reload-only'))await offline();report.status='captured-review-required';return;
 }
 // Same-room lobby theme toggles exercise cached environment replacement without
 // pretending that a stalemated match will naturally finish under a fixed input.
 for(const arena of ['Volcano','Forest']){await config(a,arena);await until(()=>b.lobby.settings.arena===arena,'peer lobby switch');for(const c of [a,b]){await expand(c,false);await shot(c,arena+'-switch-'+report.images.length);}}
 for(const [index,arena] of ['Forest','Volcano','Forest'].entries()){
  if(index>0){await leave(a,b);await leave(b);a.left=false;b.left=false;await admit(a);await admit(b,a.code);}
  await until(()=>[a,b].every(c=>c.lobby.phase==='Lobby'),'both actual lobby');
  for(const c of [a,b]){await c.page.keyboard.up('Space');await c.page.keyboard.up('a');}
  await config(a,arena);await until(()=>b.lobby.settings.arena===arena,'peer theme');
  for(const c of [a,b]){await expand(c,false);await shot(c,arena+'-lobby-'+report.images.length);}
  const from=now();for(const c of [a,b])c.label=arena+'-'+report.checks.length;await ready(a,b);
  await until(()=>[a,b].every(c=>c.frames.filter(x=>x.at_ms>from).length>12),'actual live snapshots');
  for(const c of [a,b]){await shot(c,arena+'-playing-'+report.images.length);}
  // Escape is a local online menu and must not stop authoritative ticks.
  if(arena==='Volcano'){
   await focus(a);await tap(a,'Escape');await a.page.waitForFunction(()=>JSON.parse(globalThis.ryggattackHud??'{}').menu===true);const tick=b.last.tick;await shot(a,'online-menu');await sleep(1500);assert(b.last.tick>tick+32,'online server advances under menu');await tap(a,'Escape');await a.page.waitForFunction(()=>JSON.parse(globalThis.ryggattackHud??'{}').menu===false);check('online menu does not pause server',{before_tick:tick,after_tick:b.last.tick});
  }
  check(arena+' actual gameplay state agreement',{...agreement(a,b,from,arena),inputs:a.inputs.filter(x=>x.at_ms>from&&x.fire).length});
  assert(a.inputs.some(i=>i.at_ms>from&&i.fire)&&b.inputs.some(i=>i.at_ms>from&&i.fire),'both real fire');
  if(report.checks.filter(x=>x.name==='Forest actual gameplay state agreement').length===1){
   // Interrupt only owned loopback proxy; both rendered clients remain alive.
   const identity={...a.identity},count=a.welcomes.length;expectedOutage=true;blocked.add(a.name);
   for(const p of pipes)if(p.name===a.name){p.up.destroy();p.down.destroy();}
   await until(()=>b.lobby.humans.some(h=>h.id===identity.participant&&!h.connected),'server observes disconnect');
   blocked.delete(a.name);await until(()=>a.welcomes.length>count,'actual reconnect');assert.deepEqual(a.identity,identity);
   const restored=now();await until(()=>a.frames.filter(x=>x.at_ms>restored).length>12,'post-reconnect frames');expectedOutage=false;
   check('same identity reconnect with both renderers alive',agreement(a,b,restored,arena));await shot(a,'reconnected');
   await a.page.keyboard.up('Space');await a.page.keyboard.up('a');const released=a.inputs.length;await until(()=>a.inputs.slice(released).some(i=>!i.fire),'post-reconnect release sampled');await focus(a);await a.page.keyboard.down('Space');await a.page.keyboard.down('a');
  }
 }
 // Leave old room, then create/join a different room and render fresh Volcano state.
 const old=a.identity.room;await leave(a,b);await leave(b);a.left=false;b.left=false;
 await admit(a);await admit(b,a.code);assert.notEqual(a.identity.room,old);await config(a,'Volcano',7);const from=now();await ready(a,b);
 await until(()=>a.frames.filter(x=>x.at_ms>from).length>16,'other room actual states');check('other room distinct identity and common snapshots',agreement(a,b,from,'Volcano'));
 await shot(a,'other-room-volcano');await shot(b,'other-room-volcano');
 // Stop second renderer only AFTER concurrent reconnect and both-theme proof.
 await leave(b,a);await close(b);
 const identity={...a.identity},count=a.welcomes.length;expectedOutage=true;await a.page.reload({waitUntil:'domcontentloaded'});
 await until(()=>a.welcomes.length>count,'reload saved seat',120000);assert.deepEqual(a.identity,identity);expectedOutage=false;
 await shot(a,'reload-volcano');check('actual reload restores same saved seat, second renderer closed');
 await leave(a);await close(a);
 await offline();report.status='captured-review-required';
}
async function offline(){
 // Offline renderer is launched only after both online Chromium processes exited.
 for(const arena of ['Forest','Volcano']){
  const o=await browser('Offline'+arena,true);await focus(o);await shot(o,'main-menu');
  await tap(o,'Enter');await tap(o,'w');await tap(o,'ArrowRight');await tap(o,'Enter');
  if(arena==='Volcano'){await tap(o,'ArrowRight');await tap(o,'ArrowRight');await tap(o,'Enter');await tap(o,'ArrowLeft');await tap(o,'ArrowLeft');}
  await shot(o,'solo-lobby');await tap(o,'ArrowLeft');await tap(o,'Enter');
  await sleep(3000);await shot(o,'running');await o.page.keyboard.down('d');await o.page.keyboard.down('Space');await sleep(3500);await o.page.keyboard.up('d');await o.page.keyboard.up('Space');await shot(o,'real-steering-fire');
  await tap(o,'Escape');await sleep(2000);const p1=await shot(o,'paused');await sleep(3000);const p2=await shot(o,'paused-later');
  check(arena+' offline pause pixel comparison',{equal:sha(p1)===sha(p2),caveat:'full canvas menu image equality; visually review gameplay and pause images'});assert.equal(sha(p1),sha(p2),'offline paused image stable');
  await tap(o,'Escape');await sleep(3000);const resumed=await shot(o,'resumed');assert.notEqual(sha(resumed),sha(p2));check(arena+' offline actual input, pause stable, resume changes rendered canvas');await close(o);
 }
}
try{
 const build=JSON.parse(fs.readFileSync(JSON.parse(fs.readFileSync(path.join(ROOT,'verification/final-acceptance/latest-build.json'))).result));assert.equal(build.status,'passed');
 report.build_receipt_sha256=sha(fs.readFileSync(JSON.parse(fs.readFileSync(path.join(ROOT,'verification/final-acceptance/latest-build.json'))).result));
 report.artifacts=build.artifacts;for(const [p,h]of Object.entries(build.artifacts))assert.equal(sha(fs.readFileSync(path.join(ROOT,p))),h);
 report.harness_sha256=sha(fs.readFileSync(fileURLToPath(import.meta.url)));fs.copyFileSync(fileURLToPath(import.meta.url),path.join(OUT,'executed-harness.mjs'));
 await local();await run();
}catch(e){report.status='failed';report.failure=String(e.stack??e).replace(/(?:https?|wss?):\/\/[^\s]+/g,'[local endpoint]');console.log('FAILED '+report.failure);}
finally{
 for(const c of clients)if(!c.closed){try{if(c.identity&&!c.left)await leave(c);}catch(e){report.errors.push({cleanup:c.name,error:e.message});}try{await close(c);}catch(e){report.errors.push({cleanup:c.name,error:e.message});}}
 for(const p of pipes){p.up.destroy();p.down.destroy();}
 if(backendLife){const r=await stopOwnedProcess(backendLife,async()=>{backend.kill('SIGTERM');await backendLife.exit;});report.cleanup.push({backend:r});if(!r.valid)report.errors.push({cleanup:'backend failed'});}
 if(front?.listening){front.closeAllConnections();await new Promise(r=>front.close(r));report.cleanup.push({http_closed:!front.listening});}
 report.total_ms=now();
 report.clients=clients.map(c=>({name:c.name,pid:c.entry?.owned.process().pid,browser_version:c.entry?.browser.version(),identity:c.identity??null,closed:c.closed===true,left:c.left===true,explicit_leave_count:c.leaves}));
 for(const [file,data]of [['states.json',clients.map(c=>({name:c.name,frames:c.frames}))],['inputs.json',clients.map(c=>({name:c.name,inputs:c.inputs,welcomes:c.welcomes,lobbies:c.lobbies}))]])fs.writeFileSync(path.join(OUT,file),JSON.stringify(redact(data,secrets))+'\n');
 if(report.errors.length)report.status='failed';
 if(!publishSoloEvidence(OUT,redact(report,secrets),secrets,{privacyFailed}))report.status='failed';
 console.log(JSON.stringify({status:report.status,out:OUT}));process.exitCode=report.status==='captured-review-required'?0:1;
}
