"""Final-source serial gates and full release WASM; run in bounded service."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import time
import tarfile

ROOT = Path(__file__).resolve().parents[2]
BASE = Path(__file__).resolve().parent
OUT = BASE / ('build-' + datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%SZ'))
OUT.mkdir(parents=True)
ENV = {'HOME': '/home/hermes', 'PATH': '/home/hermes/.cargo/bin:/home/hermes/.local/bin:/usr/local/bin:/usr/bin:/bin',
       'LANG': 'C.UTF-8', 'TMPDIR': '/home/hermes/.hermes/profiles/developer/cache/scratch',
       'RUSTFLAGS': ' -L native=/home/hermes/.local/sysroot/usr/lib/x86_64-linux-gnu',
       'LIBRARY_PATH': '/home/hermes/.local/sysroot/usr/lib/x86_64-linux-gnu',
       'CARGO_TARGET_DIR': '/home/hermes/src/ryggattack/target', 'CARGO_BUILD_JOBS': '1', 'BINARYEN_CORES': '1'}
def sha(p):
    with open(p, 'rb') as f:
        return hashlib.file_digest(f, 'sha256').hexdigest()
def sources():
    paths = [ROOT/'Cargo.toml', ROOT/'Cargo.lock']
    for folder in ['src', 'tests', 'scripts', 'web', 'assets']:
        paths += [p for p in (ROOT/folder).rglob('*') if p.is_file()]
    return {str(p.relative_to(ROOT)): sha(p) for p in sorted(paths)}
result = {'status': 'running', 'head': subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),
          'sources': sources(), 'helper_sha256': sha(__file__), 'stages': [], 'cargo_jobs': 1, 'binaryen_cores': 1}
def save():
    (OUT/'result.json').write_text(json.dumps(result, indent=2)+'\n')
    (BASE/'latest-build.json').write_text(json.dumps({'result': str(OUT/'result.json')})+'\n')
save()
with tarfile.open(OUT/'source.tar.gz','w:gz') as a:
    for p in result['sources']:
        a.add(ROOT/p,arcname=p)
result['source_archive_sha256'] = sha(OUT/'source.tar.gz')
try:
    group=Path('/proc/self/cgroup').read_text().split('0::')[1].strip().lstrip('/')
    cg=Path('/sys/fs/cgroup')/group
    assert int((cg/'memory.max').read_text()) == 6*1024**3
    stages = [('all-node-unit-gates', ['node','--test',*[str(p.relative_to(ROOT)) for p in sorted((ROOT/'scripts').glob('*.test.mjs'))]]),
              ('chart-version', ['python3','scripts/update-chart-version.test.py']),
              ('helm-lint', ['helm','lint','charts/ryggattack','--strict']),
              ('chart-contract', ['/home/hermes/.hermes/hermes-agent/venv/bin/python','scripts/chart-test.py']),
              ('headless-gameplay', ['python3','scripts/headless-smoke.py']),
              ('production-runtime', ['node','scripts/production-smoke.mjs']),
              ('socket-runtime', ['node','scripts/network-sockets.mjs']),
              ('full-release-wasm', ['bash','scripts/build-web.sh'])]
    for name,cmd in stages:
        assert shutil.disk_usage(ROOT).free > 2*1024**3, 'disk headroom below 2GiB; no automatic cleanup'
        item={'name':name,'command':cmd,'free_before':shutil.disk_usage(ROOT).free,'status':'running'}
        result['stages'].append(item); save(); start=time.monotonic()
        with (OUT/(name+'.log')).open('wb') as log:
            p=subprocess.run(cmd,cwd=ROOT,env=ENV,stdout=log,stderr=subprocess.STDOUT)
        item.update(exit_code=p.returncode,seconds=round(time.monotonic()-start,3),status='passed' if p.returncode==0 else 'failed'); save()
        assert p.returncode==0, name+' failed'
    assert sources()==result['sources'], 'source changed'
    result['artifacts']={str(p.relative_to(ROOT)):sha(p) for p in (ROOT/'dist/web').rglob('*') if p.is_file()}
    result['native']={str(p):sha(p) for p in (ROOT/'target/debug').glob('ryggattack*') if p.is_file() and not p.suffix}
    result['service_peak_bytes']=int((cg/'memory.peak').read_text())
    result['memory_events']=(cg/'memory.events').read_text()
    result['status']='passed'
except BaseException as e:
    result['status']='failed';result['error']=str(e);raise
finally:
    save();print(json.dumps({'status':result['status'],'result':str(OUT/'result.json')}),flush=True)
