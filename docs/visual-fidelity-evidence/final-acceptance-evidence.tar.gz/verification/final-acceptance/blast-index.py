from pathlib import Path
from PIL import Image, ImageDraw
import json
base=Path(__file__).resolve().parent
candidates=[]
for p in sorted(base.glob('browser-*/sequence-*Forest*.jpg')):
 im=Image.open(p).convert('RGB');px=im.load()
 pts={(x,y) for y in range(110,565) for x in range(30,760) if px[x,y][0]>190 and 35<px[x,y][1]<100 and px[x,y][2]<40}
 groups=[]
 while pts:
  q=[pts.pop()];comp=[]
  while q:
   x,y=q.pop();comp.append((x,y))
   for n in [(x-1,y),(x+1,y),(x,y-1),(x,y+1)]:
    if n in pts:pts.remove(n);q.append(n)
  if len(comp)>50:
   xs=[x for x,y in comp];ys=[y for x,y in comp];groups.append([min(xs),min(ys),max(xs)+1,max(ys)+1,len(comp)])
 if len(groups)>1:candidates.append({'file':str(p.relative_to(base)),'groups':groups})
canvas=Image.new('RGB',(1200,max(1,(len(candidates)+3)//4)*245),(20,20,20));d=ImageDraw.Draw(canvas)
for i,c in enumerate(candidates):
 im=Image.open(base/c['file']);im.thumbnail((300,225));x=i%4*300;y=i//4*245;canvas.paste(im,(x,y));d.text((x,y+225),str(i),fill='white')
canvas.save(base/'blast-candidates.jpg');(base/'blast-candidates.json').write_text(json.dumps(candidates,indent=2)+'\n');print('multi-blast frames',len(candidates))
