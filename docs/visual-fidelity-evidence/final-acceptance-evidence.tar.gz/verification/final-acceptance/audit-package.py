from pathlib import Path
import hashlib, io, json, re, tarfile, subprocess
BASE=Path(__file__).resolve().parent; ROOT=BASE.parents[1]
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
b=json.loads((BASE/'build-20261025T124108Z/result.json').read_text())
for group in ['sources','artifacts','native']:
 for p,h in b[group].items():assert sha(ROOT/p)==h,p
scanned=0;nested=0
key_header=re.compile(b'-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----')
def scan(name, data, depth=0):
 global scanned,nested
 scanned+=1
 assert not key_header.search(data),'private-key signature: '+name
 if name.endswith('.tar.gz'):
  assert depth<3
  nested+=1
  with tarfile.open(fileobj=io.BytesIO(data),mode='r:gz') as t:
   for m in t.getmembers():
    assert m.isfile() and not m.name.startswith('/') and '..' not in Path(m.name).parts,m.name
    scan(name+'!'+m.name,t.extractfile(m).read(),depth+1)
archive=BASE/'final-acceptance-evidence.tar.gz'
with tarfile.open(archive,'r:gz') as t:
 manifest=json.loads(t.extractfile('verification/final-acceptance/package-manifest.json').read())
 assert set(t.getnames())==set(manifest)|{'verification/final-acceptance/package-manifest.json'}
 for p,h in manifest.items():
  data=t.extractfile(p).read();assert hashlib.sha256(data).hexdigest()==h,p
  scan(p,data)
for p in BASE.glob('*/results.json'):
 r=json.loads(p.read_text());assert r['private_material_negative_scan']['passed'],str(p)
# Parse actual TAP/native output rather than relying on manually copied totals.
log=(BASE/'build-20261025T124108Z/all-node-unit-gates.log').read_text()
node_pass=int(re.findall(r'^# pass (\d+)$',log,re.M)[-1]);assert node_pass==168
native=(ROOT/'verification/arena-presentation/checks-20261025T123854Z/native-tests.log').read_text()
native_pass=sum(map(int,re.findall(r'test result: ok\. (\d+) passed;',native)));assert native_pass==216
ps=subprocess.run(['ps','-eo','pid=,comm='],text=True,capture_output=True,check=True)
active=[line.strip() for line in ps.stdout.splitlines() if re.search(r'\b(chromium|chrome|ryggattack(?:-server)?|cargo|rustc|wasm-opt)$',line)]
assert not active,active
result={'status':'passed','archive_sha256':sha(archive),'archive_bytes':archive.stat().st_size,'archive_members':len(manifest)+1,'readback_hashes_verified':True,'runtime_native_generated_unchanged':True,'native_tests_passed':native_pass,'node_tests_passed':node_pass,'signature_scanned_members_including_nested':scanned,'nested_source_archives_scanned':nested,'private_scan_scope':'Independent decompressed private-key signature scan; each browser receipt separately records in-run exact known-secret byte and pre-capture DOM checks. Not OCR or a blanket proof of arbitrary secret absence.','active_build_or_game_processes':active}
(BASE/'AUDIT.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
