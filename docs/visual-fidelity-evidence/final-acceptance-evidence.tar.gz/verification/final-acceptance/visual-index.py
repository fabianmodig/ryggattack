from pathlib import Path
from PIL import Image, ImageDraw
import json
base=Path(__file__).resolve().parent
candidates=[]
for p in sorted(base.glob('browser-*/sequence-*.jpg')):
 im=Image.open(p).convert('RGB'); px=im.load()
 pts={(x,y) for y in range(110,560) for x in range(50,750) if px[x,y][2]>px[x,y][0]+45 and px[x,y][2]>140 and px[x,y][1]>90}
 while pts:
  q=[pts.pop()]; comp=[]
  while q:
   x,y=q.pop();comp.append((x,y))
   for n in [(x-1,y),(x+1,y),(x,y-1),(x,y+1)]:
    if n in pts:pts.remove(n);q.append(n)
  xs=[x for x,y in comp];ys=[y for x,y in comp];w=max(xs)-min(xs)+1;h=max(ys)-min(ys)+1
  if 10<=len(comp)<=150 and 10<=max(w,h)<=35 and max(w,h)/min(w,h)>=2.2:
   box=[max(0,min(xs)-20),max(0,min(ys)-20),min(800,max(xs)+21),min(600,max(ys)+21)]
   candidates.append({'file':str(p.relative_to(base)),'box':box,'pixels':len(comp)})
canvas=Image.new('RGB',(1000,((len(candidates)+7)//8)*110),(20,20,20));d=ImageDraw.Draw(canvas)
for i,c in enumerate(candidates):
 im=Image.open(base/c['file']).crop(c['box']);im.thumbnail((120,80));x=i%8*125;y=i//8*110;canvas.paste(im,(x,y));d.text((x,y+80),str(i),fill='white')
canvas.save(base/'blue-candidates.jpg');(base/'blue-candidates.json').write_text(json.dumps(candidates,indent=2)+'\n');print('candidates',len(candidates))
