from pathlib import Path
import sys,json
root=Path(sys.argv[1]);theme=sys.argv[2]
actions=[('Enter','lobby'),('w','joined'),('ArrowRight','bots-selected'),('Enter','bots-zero')]
if theme=='Volcano':actions += [('ArrowRight','target-selected'),('ArrowRight','arena-selected'),('Enter','arena-volcano'),('ArrowLeft','target-back'),('ArrowLeft','bots-back')]
actions += [('ArrowLeft','start-selected'),('Enter','running'),('d','steering'),('Space','firing'),('Escape','paused'),(None,'paused-later'),('Escape','resumed')]
for i,(key,label) in enumerate(actions,1):
 p=root/'commands'/f'{i:03}.json';assert not p.exists()
 p.write_text(json.dumps({'key':key,'label':label,'hold_ms':3000,'settle_ms':5000})+'\n')
print('queued',len(actions),'real-input/capture commands; close separately after inspection')
