from pathlib import Path
import json
p=Path('/proc/self/cgroup').read_text();g=Path('/sys/fs/cgroup')/p.split('0::')[1].strip().lstrip('/')
print(json.dumps({'cgroup':str(g),'values':{n:(g/n).read_text().strip() for n in ['memory.current','memory.max','memory.peak','memory.events','cpu.max','cpu.stat','pids.current','pids.max']}},indent=2))
