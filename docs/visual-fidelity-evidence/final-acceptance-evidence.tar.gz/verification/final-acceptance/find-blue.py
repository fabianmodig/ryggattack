from pathlib import Path
import sys
from PIL import Image
root=Path(sys.argv[1])
for p in sorted(root.glob('sequence-ArenaB-Forest-1-*.jpg')):
 im=Image.open(p).convert('RGB');px=im.load();w,h=im.size
 points={(x,y) for y in range(105,min(h,570)) for x in range(w) if (lambda c:c[2]>c[0]+45 and c[2]>140 and c[1]>90 and c[1]<c[2]+5)(px[x,y])}
 while points:
  q=[points.pop()];component=[]
  while q:
   x,y=q.pop();component.append((x,y))
   for n in [(x+1,y),(x-1,y),(x,y+1),(x,y-1)]:
    if n in points:points.remove(n);q.append(n)
  if 4<=len(component)<=65:
   print(p.name,len(component),[min(x for x,y in component),min(y for x,y in component),max(x for x,y in component),max(y for x,y in component)])
