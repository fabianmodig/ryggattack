from pathlib import Path
import hashlib,json,os,tarfile,datetime,subprocess
from PIL import Image
ROOT=Path(__file__).resolve().parents[2];BASE=Path(__file__).resolve().parent
NATIVE=ROOT/'verification/arena-presentation/checks-20261025T123854Z'
BUILD=BASE/'build-20261025T124108Z'
def sha(p):
 with open(p,'rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
n=json.loads((NATIVE/'result.json').read_text());b=json.loads((BUILD/'result.json').read_text());assert n['status']==b['status']=='passed'
assert all(b['sources'][p]==h for p,h in n['source_hashes'].items())
for mapping in [b['sources'],b['artifacts'],b['native']]:
 for p,h in mapping.items():assert sha(ROOT/p)==h,p
reports=[];owned=[]
for p in sorted(BASE.glob('*/results.json')):
 r=json.loads(p.read_text());reports.append({'directory':str(p.parent.relative_to(ROOT)),'status':r['status'],'mode':r.get('mode'),'result_sha256':sha(p),'failure':r.get('failure'),'checks':r.get('checks',[]),'private_scan':r.get('private_material_negative_scan'),'cleanup':r.get('cleanup')})
 for c in r.get('clients',[]):
  if c.get('pid'):owned.append(c['pid'])
 if r.get('pid'):owned.append(r['pid'])
 assert r.get('private_material_negative_scan',{}).get('passed'),str(p)
for pid in set(owned):
 try:os.kill(pid,0)
 except ProcessLookupError:continue
 raise AssertionError('owned PID still exists: '+str(pid))
pause=[]
for arena in ['Forest','Volcano']:
 dirs=sorted(BASE.glob('pilot-'+arena+'-*'));assert dirs
 p=dirs[-1];r=json.loads((p/'results.json').read_text());assert r['status']=='captured-review-required'
 a=Image.open(p/'paused.png').convert('RGB');z=Image.open(p/'paused-later.png').convert('RGB');res=Image.open(p/'resumed.png').convert('RGB')
 assert a.size==z.size and a.tobytes()==z.tobytes(),arena+' paused pixels changed'
 assert a.tobytes()!=res.tobytes(),arena+' resume pixels unchanged'
 pause.append({'arena':arena,'directory':str(p.relative_to(ROOT)),'pause_pixel_equal':True,'resume_pixel_changed':True,'images':{f:sha(p/f) for f in ['running.png','steering.png','firing.png','paused.png','paused-later.png','resumed.png']}})
reload=[r for r in reports if any('actual reload restores' in c['name'] for c in r['checks']) and r['status']=='captured-review-required'];assert reload,'missing successful reload supplement'
result={'status':'composite-evidence-ready-for-independent-review','scope':'Runtime unchanged; no single full-lifecycle harness is relabeled green. Positive cases from failed runs are complemented by passing direct-GPU offline/reload supplements.','head':b['head'],'native_passed':n['native_passed'],'native_stages':n['stages'],'build_stages':b['stages'],'source_archive_sha256':b['source_archive_sha256'],'wasm_sha256':b['artifacts']['dist/web/ryggattack_bg.wasm'],'js_sha256':b['artifacts']['dist/web/ryggattack.js'],'source_native_artifacts_unchanged':True,'owned_browser_pids_absent':sorted(set(owned)),'offline_pause':pause,'reports':reports,'limits':['Native manual graphics deferred.','Anonymous rotating bearer theft limitation remains accepted.','Online uses fixed sparse rendering, not offline quality governor.','Compositor sequence filenames/nearby wire ticks are not exact GPU-to-wire synchronization.','Requested teardown SIGKILL is recorded separately from graceful exit; prior failed statuses remain failed.','No public rooms, remote publication, merge, deployment or production restart.']}
(BASE/'FINAL-RESULT.json').write_text(json.dumps(result,indent=2)+'\n')
# Preserve source/build/native/failed and successful evidence without copying target/cache.
archive=BASE/'final-acceptance-evidence.tar.gz'
generated_receipts={archive,BASE/'package-manifest.json',BASE/'package-receipt.json',BASE/'AUDIT.json'}
files=[p for p in BASE.rglob('*') if p.is_file() and p not in generated_receipts]
files += [p for p in NATIVE.rglob('*') if p.is_file()]
original=ROOT/'verification/online-explosion/2026-10-25T13-06-24-693Z-3f9c5cb9d2b7'
files += [p for p in original.rglob('*') if p.is_file()]
manifest={str(p.relative_to(ROOT)):sha(p) for p in sorted(set(files))}
(BASE/'package-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
with tarfile.open(archive,'w:gz') as tar:
 for p in sorted(set(files+[BASE/'package-manifest.json'])):tar.add(p,arcname=str(p.relative_to(ROOT)))
with tarfile.open(archive,'r:gz') as tar:
 members={m.name:m for m in tar.getmembers()};assert set(members)==set(manifest)|{'verification/final-acceptance/package-manifest.json'}
 for p,h in manifest.items():assert hashlib.sha256(tar.extractfile(members[p]).read()).hexdigest()==h,p
receipt={'archive':str(archive),'sha256':sha(archive),'bytes':archive.stat().st_size,'members':len(members),'manifest_readback_verified':True}
(BASE/'package-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt));print('FINAL RESULT '+str(BASE/'FINAL-RESULT.json'))
