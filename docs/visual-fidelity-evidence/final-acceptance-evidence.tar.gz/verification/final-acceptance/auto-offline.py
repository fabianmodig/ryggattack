from pathlib import Path
import subprocess,sys,json
root=Path(__file__).resolve().parents[2]
p=subprocess.Popen(['node','verification/final-acceptance/offline-pilot.mjs',sys.argv[1]],cwd=root,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,bufsize=1)
out=None
for line in p.stdout:
 print(line,end='',flush=True)
 if line.startswith('CAPTURE ') and line.strip().endswith('/000-initial.png'):
  out=Path(line.strip()[8:]).parent
  subprocess.run(['python3','verification/final-acceptance/enqueue-pilot.py',str(out),sys.argv[1]],cwd=root,check=True)
 if line.startswith('CAPTURE ') and line.strip().endswith('/resumed.png'):
  (out/'commands/999.json').write_text(json.dumps({'close':True})+'\n')
raise SystemExit(p.wait())
