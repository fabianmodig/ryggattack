// Stepped local GPU acceptance. Agent supplies only real key actions via owned JSON files.
import fs from 'node:fs';import path from 'node:path';import http from 'node:http';import crypto from 'node:crypto';import assert from 'node:assert/strict';import {createRequire} from 'node:module';import {fileURLToPath} from 'node:url';
import {capturePrivateScreenshot,publishSoloEvidence} from '../../scripts/solo-bots-helpers.mjs';
import {watchOwnedProcess,stopOwnedProcess} from '../../scripts/online-explosion-cleanup.mjs';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'../..'),web=path.join(root,'dist/web');
const theme=process.argv[2]??'Forest';assert(['Forest','Volcano'].includes(theme));
const out=path.join(root,'verification/final-acceptance','pilot-'+theme+'-'+new Date().toISOString().replace(/[:.]/g,'-'));fs.mkdirSync(path.join(out,'commands'),{recursive:true});
const sha=b=>crypto.createHash('sha256').update(b).digest('hex'),sleep=ms=>new Promise(r=>setTimeout(r,ms));
const secrets=new Set(),report={status:'running',scope:'one offline WASM client only, actual ?quality=0; stepped keyboard and direct CDP GPU captures',theme,actions:[],errors:[],images:[]};
const t=performance.now(),now=()=>Math.round(performance.now()-t);
const build=JSON.parse(fs.readFileSync(JSON.parse(fs.readFileSync(path.join(root,'verification/final-acceptance/latest-build.json'))).result));assert.equal(build.status,'passed');for(const[p,h]of Object.entries(build.artifacts))assert.equal(sha(fs.readFileSync(path.join(root,p))),h);report.artifacts=build.artifacts;
report.harness_sha256=sha(fs.readFileSync(fileURLToPath(import.meta.url)));fs.copyFileSync(fileURLToPath(import.meta.url),path.join(out,'executed-pilot.mjs'));
const server=http.createServer((req,res)=>{let f;try{let p=decodeURIComponent(req.url.split('?')[0]);if(p.includes('\0'))throw Error();if(p.endsWith('/'))p+='index.html';f=path.resolve(web,'.'+p);}catch{res.writeHead(400).end();return;}if(!f.startsWith(web+path.sep)){res.writeHead(403).end();return;}fs.readFile(f,(e,b)=>{if(e){res.writeHead(404).end();return;}res.writeHead(200,{'content-type':({'.html':'text/html','.js':'text/javascript','.mjs':'text/javascript','.wasm':'application/wasm'})[path.extname(f)]??'application/octet-stream','content-security-policy':"connect-src 'self'; object-src 'none'"}).end(b);});});
let owner,browser,page,life,cdp,privacyFailed=false;
function save(){fs.writeFileSync(path.join(out,'progress.json'),JSON.stringify(report,null,2)+'\n');}
async function capture(label){const before=now();let image;await capturePrivateScreenshot(page,secrets,async()=>{image=await Promise.race([cdp.send('Page.captureScreenshot',{format:'png',fromSurface:true,captureBeyondViewport:false}),sleep(60000).then(()=>{throw Error('direct CDP capture deadline');})]);});const file=label+'.png',bytes=Buffer.from(image.data,'base64');fs.writeFileSync(path.join(out,file),bytes);report.images.push({file,before_ms:before,after_ms:now(),sha256:sha(bytes)});save();console.log('CAPTURE '+path.join(out,file));}
try{
 await new Promise(r=>server.listen(0,'127.0.0.1',r));const origin=`http://127.0.0.1:${server.address().port}`;
 const {chromium}=createRequire('/home/hermes/.npm/_npx/e41f203b7505f1fb/node_modules/playwright/package.json')('playwright');
 owner=await chromium.launchServer({host:'127.0.0.1',args:['--use-angle=swiftshader','--enable-unsafe-swiftshader','--ignore-gpu-blocklist']});life=watchOwnedProcess(owner.process());browser=await chromium.connect(owner.wsEndpoint());report.pid=owner.process().pid;report.browser_version=browser.version();
 page=await browser.newPage({viewport:{width:800,height:600}});await page.route('**/*',r=>new URL(r.request().url()).origin===origin||['blob:','data:'].includes(new URL(r.request().url()).protocol)?r.continue():r.abort());
 page.on('pageerror',e=>report.errors.push(e.message));page.on('console',m=>{if(m.type()==='error')report.errors.push(m.text());});page.on('websocket',()=>report.errors.push('offline client unexpectedly opened socket'));
 await page.goto(origin+'/?quality=0',{waitUntil:'domcontentloaded'});await page.waitForFunction(()=>!document.getElementById('status'),null,{timeout:120000});await page.locator('canvas').focus();cdp=await page.context().newCDPSession(page);await sleep(3000);await capture('000-initial');
 const used=new Set();let end=false;
 while(!end){
  const commands=fs.readdirSync(path.join(out,'commands')).filter(n=>n.endsWith('.json')&&!used.has(n)).sort();
  if(!commands.length){await sleep(100);continue;}
  for(const name of commands){const c=JSON.parse(fs.readFileSync(path.join(out,'commands',name)));used.add(name);const item={command:name,...c,before_ms:now()};report.actions.push(item);save();
   if(c.close){end=true;break;}
   if(c.key){assert(['Enter','Escape','w','a','s','d','ArrowLeft','ArrowRight','Space','F3'].includes(c.key));await page.keyboard.down(c.key);await sleep(c.hold_ms??3000);await page.keyboard.up(c.key);}
   await sleep(c.settle_ms??3000);await capture(c.label??name.slice(0,-5));item.after_ms=now();save();
  }
 }
 report.status='captured-review-required';
}catch(e){report.status='failed';report.failure=String(e.stack??e);if(e.name==='PrivacyViolation')privacyFailed=true;}
finally{
 if(page&&!page.isClosed())await page.close().catch(()=>{});
 if(life){const r=await stopOwnedProcess(life,async()=>{await owner.close();await browser.close();},{closeMs:60000});let absent=false;try{process.kill(owner.process().pid,0);}catch(e){if(e.code==='ESRCH')absent=true;}report.cleanup={browser:r,owned_process_absent:absent};if(!absent||r.unexpected)report.status='failed';}
 if(server.listening){server.closeAllConnections();await new Promise(r=>server.close(r));report.http_closed=!server.listening;}
 if(report.errors.length)report.status='failed';report.total_ms=now();save();if(!publishSoloEvidence(out,report,secrets,{privacyFailed}))report.status='failed';console.log(JSON.stringify({status:report.status,out}));process.exitCode=report.status==='captured-review-required'?0:1;
}
